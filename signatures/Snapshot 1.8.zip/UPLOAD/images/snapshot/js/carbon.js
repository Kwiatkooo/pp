/* jQuery cookie */

jQuery.cookie=function(name,value,options){if(typeof value!='undefined'){options=options||{};if(value===null){value='';options=$.extend({},options);options.expires=-1;}
var expires='';if(options.expires&&(typeof options.expires=='number'||options.expires.toUTCString)){var date;if(typeof options.expires=='number'){date=new Date();date.setTime(date.getTime()+(options.expires*24*60*60*1000));}else{date=options.expires;}
expires='; expires='+ date.toUTCString();}
var path=options.path?'; path='+(options.path):'';var domain=options.domain?'; domain='+(options.domain):'';var secure=options.secure?'; secure':'';document.cookie=[name,'=',encodeURIComponent(value),expires,path,domain,secure].join('');}else{var cookieValue=null;if(document.cookie&&document.cookie!=''){var cookies=document.cookie.split(';');for(var i=0;i<cookies.length;i++){var cookie=jQuery.trim(cookies[i]);if(cookie.substring(0,name.length+ 1)==(name+'=')){cookieValue=decodeURIComponent(cookie.substring(name.length+ 1));break;}}}
return cookieValue;}};

/* sidebar */

jQuery(function(){
	jQuery(".clickedbuttons").hide();
	jQuery(".buttons").click(
		function(){
		jQuery(".sidebar").animate({
			height:"hide",opacity:0},500,
		function(){
			jQuery(".forums").animate({width:"100%"},500);});
			jQuery(this).hide();jQuery(".clickedbuttons").show();
			jQuery.cookie("sidebar","collapsed",{expires:365});
		return false;});
			jQuery(".clickedbuttons").click(function(){
			jQuery(".forums").animate({width:"80%"},500,function(){
			jQuery(".sidebar").animate({height:"show",opacity:1},500);});
			jQuery(this).hide();jQuery(".buttons").show();
			jQuery.cookie("sidebar","expanded",{expires:365});
			return false;});
			if(jQuery.cookie("sidebar")=="collapsed"){
				jQuery(".buttons").hide();
				jQuery(".clickedbuttons").show();
				jQuery(".forums").css("width","100%");
				jQuery(".sidebar").hide();};});
	


/*profil*/
jQuery(document).ready(function() {
 
 //When page loads...
 jQuery(".tab_content").hide(); //Hide all content
 jQuery("ul.tabs li:first").addClass("active").show(); //Activate first tab
 jQuery(".tab_content:first").show(); //Show first tab content
 
 //On Click Event
 jQuery("ul.tabs li").click(function() {
 
  jQuery("ul.tabs li").removeClass("active"); //Remove any "active" class
  jQuery(this).addClass("active"); //Add "active" class to selected tab
  jQuery(".tab_content").hide(); //Hide all tab content
 
 
  var activeTab = jQuery(this).find("a").attr("href"); //Find the href attribute value to identify the active tab + content
  jQuery(activeTab).fadeIn(); //Fade in the active ID content
  return false;
 });
 
});
