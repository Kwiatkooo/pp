// Login Form
jQuery(function() {
    var button = jQuery('#loginButton');
    var box = jQuery('#loginBox');
    var form = jQuery('#loginForm');
    button.mouseup(function(login) {
        box.toggle();
        button.toggleClass('active');
    });
    form.mouseup(function() { 
        return false;
    });
    jQuery(this).mouseup(function(login) {
        if(!(jQuery(login.target).parent('#loginButton').length > 0)) {
            button.removeClass('active');
            box.hide();
        }
    });
});

jQuery(function() {
    var button = jQuery('#PowiadomieniaButton');
    var box = jQuery('#PowiadomieniaBox');
    var form = jQuery('#PowiadomieniaForm');
    button.mouseup(function(login) {
        box.toggle();
        button.toggleClass('active');
    });
    form.mouseup(function() { 
        return false;
    });
    jQuery(this).mouseup(function(login) {
        if(!(jQuery(login.target).parent('#PowiadomieniaButton').length > 0)) {
            button.removeClass('active');
            box.hide();
        }
    });
});

jQuery(document).ready(function() {
	jQuery('a.login-window').click(function() {
		
		// Getting the variable's value from a link 
		var loginBox = jQuery(this).attr('href');

		//Fade in the Popup and add close button
		jQuery(loginBox).fadeIn(300);
		
		//Set the center alignment padding + border
		var popMargTop = (jQuery(loginBox).height() + 24) / 2; 
		var popMargLeft = (jQuery(loginBox).width() + 24) / 2; 
		
		jQuery(loginBox).css({ 
			'margin-top' : -popMargTop,
			'margin-left' : -popMargLeft
		});
		
		// Add the mask to body
		jQuery('body').append('<div id="mask"></div>');
		jQuery('#mask').fadeIn(300);
		
		return false;
	});
	
	// When clicking on the button close or the mask layer the popup closed
jQuery('.btn_close').click(function(e){
jQuery('#mask , .login-popup').fadeOut(300 , function() {
		jQuery('#mask').remove();  
	}); 

return false;
});
//	jQuery('.btn_close')('click', function() { 
//	  jQuery('#mask , .login-popup').fadeOut(300 , function() {
//		jQuery('#mask').remove();  
//	}); 
//	return false;
//	});
});