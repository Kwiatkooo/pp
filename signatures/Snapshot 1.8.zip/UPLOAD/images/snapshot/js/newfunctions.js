$(document).ready(function () {

    var file_name, file_end, file_page, ucplink, dicon, ucpbox, sidebar, sidebarToggle, expopen, expclose, thead2, thead, thead_id, n, cookies, name, thnum, quoted, quoted_split;

    // User Panel 
    ucplink = $('.user_panel_link');
    dicon = $('.dropdown_icon');
    ucpbox = $('.user_panel_box');

    ucplink.click(function (e) {
        e.preventDefault();
        ucpbox.slideToggle('fast');
        dicon.toggleClass('dropdown_icon_active');
        ucplink.toggleClass('user_panel_link_active');
    });

    ucplink.mouseup(function () {
        return false;
    });

    ucpbox.mouseup(function () {
        return false;
    });

    $(document).mouseup(function () {
        ucpbox.slideUp('fast');
        dicon.removeClass('dropdown_icon_active');
        ucplink.removeClass('user_panel_link_active');
    });

    // Unread PMs
    $(".pms_unread").each(function () {
        if ($(this).html() === "0") {
            $(this).removeClass("pms_unread");
            $(this).addClass("pms_unread_no");
        }
    });

    // Smooth scroll to top
    $('.toTop').click(function () {
        $('body,html').animate({
            scrollTop: 0
        }, 800);
        return false;
    });

    // Hide empty forum description boxes
    $('.thead_2 .forumdesc').filter(function () {
        return $.trim($(this).text()) === '' && $(this).children().length === 0;
    }).remove();

    // Sidebar Toggle
    sidebar = $('.index_sidebar');
    sidebarToggle = $('.sidebar_collapse i');

    $(document).on('click', '.sidebar_collapse', function () {
        if (sidebar.is(':visible')) {
            sidebarToggle.removeClass('fa-chevron-right').addClass('fa-chevron-left');
            $.cookie("sidebar", "closed", { expires: 365 });
        } else {
            sidebarToggle.removeClass('fa-chevron-left').addClass('fa-chevron-right');
            $.cookie("sidebar", "open", { expires: 365 });
        }
        sidebar.stop().animate({ width: 'toggle' }, 350);
    });

    if ($.cookie("sidebar") === "closed") {
        sidebar.hide();
        sidebarToggle.removeClass('fa-chevron-right').addClass('fa-chevron-left');
    }

    // Animated expand/collapse
    expopen = '.expcol_open';
    expclose = '.expcol_close';
    thead2 = '.thead';
    $(expclose).on("click", function () {
        thead = $(this).parent(thead2);
        thead_id = $(this).parent(thead2).attr("id");
        n = parseInt(thead_id.replace('th', ''), 10);
        $("#expcol_box" + n).slideUp();
        $(this).hide();
        thead.children(expopen).show();
        thead.animate({
            "border-radius": "5px",
            "opacity": "0.4"
        });
        $.cookie(n, "closed", {
            expires: 365
        });
        return false;
    });

    $(expopen).on("click", function () {
        thead = $(this).parent(thead2);
        thead_id = $(this).parent(thead2).attr("id");
        n = parseInt(thead_id.replace('th', ''), 10);
        $("#expcol_box" + n).slideDown();
        $(this).hide();
        thead.children(expclose).show();
        thead.animate({
            "border-radius": "5px",
            "opacity": "1"
        });
        $.cookie(n, "open", {
            expires: 365
        });
        return false;
    });

    // Restore collapses
    function get_cookies() {
        cookies = {};
        if (document.cookie && document.cookie !== '') {
            var split, i, name_value;
            split = document.cookie.split(';');
            for (i = 0; i < split.length; i += 1) {
                name_value = split[i].split("=");
                name_value[0] = name_value[0].replace(/^ /, '');
                cookies[decodeURIComponent(name_value[0])] = decodeURIComponent(name_value[1]);
            }
        }
        return cookies;
    }

    cookies = get_cookies();
    for (name in cookies) {
        if (cookies[name] === 'closed') {
            $("#expcol_box" + name).hide();
            thnum = $("#th" + name);
            thnum.css('opacity', '0.4');
            thnum.find('.expcol_open').show();
            thnum.find('.expcol_close').hide();
        }
    }

    // Multiquote fix
    if ($.cookie('multiquote') !== null) {
        quoted = $.cookie("multiquote");
        quoted_split = quoted.split('|');
        $.each(quoted_split, function () {
            $('#multiquote_link_' + this).addClass('multiquote_on');
        });
    }

    $('a.postbit_multiquote').click(function () {
        if ($(this).hasClass('multiquote_on')) {
            $(this).removeClass('multiquote_on');
        } else {
            $(this).addClass('multiquote_on');
        }
    });

});