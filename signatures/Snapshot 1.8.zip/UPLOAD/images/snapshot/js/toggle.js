jQuery.noConflict();

jQuery(function(jQuery) {
    jQuery(".collapse").hide();
    jQuery(".expand").click(function() {
        jQuery("#container, .wrap, .header, #menu").stop(true, true).delay(0).css({width: '95%'}, 300);	
        jQuery(this).hide();
        jQuery(".collapse").show();
        jQuery.cookie("resize","collapsed", {expires: 365});
        return false;
    });
    jQuery(".collapse").click(function() {
        jQuery("#container, .wrap, .header, #menu").stop(true, true).delay(0).css({width: '960px'}, 300);	
        jQuery(this).hide();
        jQuery(".expand").show();
        jQuery.cookie("resize","expanded", {expires: 365});
        return false;
    });
    if(jQuery.cookie("resize") == "collapsed") {
        jQuery(".expand").hide();
        jQuery(".collapse").show();
		jQuery("#container, .wrap, .header, #menu").css({width: '95%'});
    };
});
